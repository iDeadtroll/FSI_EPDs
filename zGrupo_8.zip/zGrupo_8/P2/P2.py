from tokenize import String


# Clase apartamentos
class Apartamentos():

    def __init__(self, id, name, sumary, description, location, photos, recomendado, price, size, rooms, price_m2,
                 bathrooms, Numphotos, type, region):
        self.id = id
        self.__name = name
        self.__sumary = sumary
        self.__description = description
        self.__location = location
        self.__photos = photos
        self.__recomendado = recomendado
        self.__price = price
        self.__size = size
        self.__rooms = rooms
        self.__price_m2 = price_m2  # pyright: reportUndefinedVariable=false
        self.__bathrooms = bathrooms
        self.__Numphotos = Numphotos
        self.__type = type
        self.__region = region

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, valor):
        self.__name = valor

    @property
    def sumary(self):
        return self.__sumary

    @sumary.setter
    def sumary(self, valor):
        self.__sumary = valor

    @property
    def description(self):
        return self.__description

    @description.setter
    def description(self, valor):
        self.__description = valor

    @property
    def location(self):
        return self.__location

    @location.setter
    def location(self, valor):
        self.__location = valor

    @property
    def photos(self):
        return self.__photos

    @photos.setter
    def photos(self, valor):
        self.__photos = valor

    @property
    def recomendado(self):
        return self.__recomendado

    @recomendado.setter
    def recomendado(self, valor):
        self.__recomendado = valor

    @property
    def price(self):
        return self.__price

    @price.setter
    def price(self, valor):
        self.__price = valor

    @property
    def size(self):
        return self.__size

    @size.setter
    def size(self, valor):
        self.__size = valor

    @property
    def rooms(self):
        return self.__rooms

    @rooms.setter
    def rooms(self, valor):
        self.__rooms = valor

    @property
    def price_m2(self):
        return self.__price_m2

    @price_m2.setter
    def price_m2(self, valor):
        self.__price_m2 = valor

    @property
    def bathrooms(self):
        return self.__bathrooms

    @bathrooms.setter
    def bathrooms(self, valor):
        self.__bathrooms = valor

    @property
    def Numphotos(self):
        return self.__Numphotos

    @Numphotos.setter
    def Numphotos(self, valor):
        self.__Numphotos = valor

    @property
    def type(self):
        return self.__type

    @type.setter
    def type(self, valor):
        self.__type = valor

    @property
    def region(self):
        return self.__region

    @region.setter
    def region(self, valor):
        self.__region = valor

    def __str__(self):
        return 'Nombre del apartamento: ' + str(self.__name) + ',descripcion del mismo: ' + str(
            self.__sumary) + ',localizacion: ' + str(self.__location) + ',fotos: ' + str(
            self.__photos) + ',recomendado: ' + str(self.__recomendado) + ',precio: ' + str(
            self.__price) + ',medidas: ' + str(self.__size) + ',habitaciones: ' + str(
            self.__rooms) + ',precio metros cuadrados: ' + str(self.__price_m2) + ',baños: ' + str(
            self.__bathrooms) + ',numero de fotos: ' + str(self.__Numphotos) + ',tipo: ' + str(
            self.__type) + ',region: ' + str(self.__region)


# clase Almacen
class Almacen():
    datos = []

    def __init__(self, datos):
        self.datos = datos

    @property
    def datos(self):
        return self.__datos

    @datos.setter
    def datos(self, valor):
        self.__datos = valor

    def altaApartamento(self, Apartamento):
        exito = False
        i = 0
        while exito is False and i < len(self.datos):
            if self.datos[i] == Apartamento:
                exito = True
            else:
                i += 1

        if exito is False:
            self.datos.append(Apartamento)
            print("OK")
        else:
            print("DUPLICADO")

    def bajaApartamento(self, ClaveApartamento):
        exito = False
        i = 0
        while exito is False and i < len(self.datos):
            if self.datos[i].id == ClaveApartamento:
                self.datos.remove(self.datos[i])
                exito = True
            else:
                i += 1
        if exito is True:
            print("OK")
        else:
            print("NO LOCALIZADO")

    def listadoApartamento(self):
        print("{:^8} {:^8} {:^8} {:^8} {:^8} {:^8} {:^8} {:^8}".format("Nombre del apartamento,descripcion del mismo,localizacion,fotos,recomendado,precio,medidas,habitaciones,precio metros cuadrados,baños,numero de fotos,tipo,region"))
        for v in self.datos:
            id_apartamento, name_apart, desc_apart, loc_apart, fot_apart, rec_apart, prec_apart, med_apart, hab_apart, precm2_apart, ba_apart, numfot_apart, type_apart, reg_apart = v
            print("{:^8} {:^8} {:^8} {:^8} {:^8} {:^8} {:^8} {:^8}".format(id_apartamento, name_apart, desc_apart,
                                                                           loc_apart, fot_apart, rec_apart, prec_apart,
                                                                           med_apart, hab_apart, precm2_apart, ba_apart,
                                                                           numfot_apart, type_apart, reg_apart))

        # Main


p1 = Apartamentos(1, "Casa pareada en calle Virxe Da Cerca", "bonito", "bonito", "Huelva",
                  "https://fotos1.imghs.net/nrd/1001/313/1001_PX987_-_412057-03687-90128313_1_2020070301074931250.jpg",
                  "recomendado", 250.000, 320, 7, 1.23, 2, 5, "Casa", "Andalucia")
p2 = Apartamentos(2, "Piso en Ensanche", "baja calidad", "bonito", "Ensanche", "https://fotos2.imghs.net/nrd//1005/065/1005_67953263065_1_2019080623083033586.jpg", "no recomendado", 50.000, 220, 5, 1.206, 1, 3, "Piso", "A Coruña")
listaApartamento = []
datos = Almacen(listaApartamento)
datos.altaApartamento(p1)
datos.altaApartamento(p2)
datos.bajaApartamento(3)