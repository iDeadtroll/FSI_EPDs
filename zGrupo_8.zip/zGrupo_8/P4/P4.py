import statistics as stat
from functools import reduce

#Diccionario del precio de los apartamentos
diccionario={0:240.000,1:260.000,2:290.000,3:270.000,4:270.000}
print(diccionario)

#Funcion Filter
avg=stat.mean(diccionario.values())
print(avg)

res=filter(lambda x: (x[0], x[1]>avg), diccionario.items())
print(res)
print(list(res))
#Sacamos la media de precio cuadrados que tienen los 5 primeros apartamentos
#Funcion Map
mapeo=dict(map(lambda x: (x[0], x[1]+30.000), diccionario.items()))
print(mapeo)
#Para probar la funcion map hemos añadido 30.000 euros de valor a cada apartamento
#Funcion reduce

res=reduce(lambda x, y: x+y, diccionario.values())
print(res)
#Sacamos el total de todos los precios que hay en los 5 apartamentos